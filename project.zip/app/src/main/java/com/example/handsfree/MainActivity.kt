package com.example.handsfree

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val names = arrayOf("Gemini (Google)", "ChatGPT (OpenAI)", "Claude (Anthropic)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, pad / 2, 0, 0) }
        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { onClick() }
        }

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        spinner.setSelection(prefs.getInt("provider", 0))
        val keyBox = EditText(this).apply {
            hint = "Paste API key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val modelBox = EditText(this).apply { hint = "Model name"; setSingleLine() }
        val wakeBox = EditText(this).apply {
            setText(prefs.getString("wake", "hey assistant"))
            setSingleLine()
        }
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                keyBox.setText(prefs.getString("key_$pos", ""))
                modelBox.setText(prefs.getString("model_$pos", Llm.defaultModel(pos)))
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        fun save() {
            val p = spinner.selectedItemPosition
            prefs.edit()
                .putInt("provider", p)
                .putString("key_$p", keyBox.text.toString().trim())
                .putString("model_$p", modelBox.text.toString().trim())
                .putString("wake", wakeBox.text.toString().trim().lowercase())
                .apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
        val svc = { Intent(this, AssistantService::class.java) }

        root.addView(TextView(this).apply { text = "Hands-Free Assistant"; textSize = 22f })
        root.addView(label("AI provider")); root.addView(spinner)
        root.addView(label("API key (stored only on this phone)")); root.addView(keyBox)
        root.addView(label("Model")); root.addView(modelBox)
        root.addView(label("Wake phrase")); root.addView(wakeBox)
        root.addView(button("Save settings") { save() })
        root.addView(button("1. Grant permissions") {
            requestPermissions(arrayOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS,
                Manifest.permission.POST_NOTIFICATIONS), 1)
        })
        root.addView(button("2. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("Start hands-free") { save(); startForegroundService(svc()) })
        root.addView(button("Talk now (skip wake word)") { startForegroundService(svc().setAction("TALK")) })
        root.addView(button("Stop") { stopService(svc()) })
        root.addView(label("Try: \"Hey assistant, pause the music\", \"set an alarm for 7 AM\", \"call Mom\", \"open YouTube\"."))

        setContentView(ScrollView(this).apply { addView(root) })
    }
}

package com.example.handsfree

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Llm {
    const val SYSTEM = """You are a hands-free voice assistant on an Android phone. Reply ONLY with one JSON object: {"speech":"short spoken reply","action":"name","args":{}}.
Actions: none; play_pause; pause; play; next; previous; volume_up; volume_down; play_music {query}; open_app {name}; set_alarm {hour (0-23), minute, label}; set_timer {seconds, label}; call {name}; send_sms {name, message}; web_search {query}; open_url {url}.
Use action "none" for chat and questions. Keep speech to 1-2 plain sentences, no markdown."""

    fun defaultModel(p: Int) = when (p) {
        0 -> "gemini-2.5-flash"
        1 -> "gpt-4o-mini"
        else -> "claude-sonnet-4-5"
    }

    fun ask(provider: Int, key: String, model: String, text: String): String {
        val url: String
        val headers: Map<String, String>
        val body: JSONObject
        when (provider) {
            0 -> {
                url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
                headers = emptyMap()
                body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))))
                    .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            }
            1 -> {
                url = "https://api.openai.com/v1/chat/completions"
                headers = mapOf("Authorization" to "Bearer $key")
                body = JSONObject()
                    .put("model", model)
                    .put("response_format", JSONObject().put("type", "json_object"))
                    .put("messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content", SYSTEM))
                        .put(JSONObject().put("role", "user").put("content", text)))
            }
            else -> {
                url = "https://api.anthropic.com/v1/messages"
                headers = mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01")
                body = JSONObject()
                    .put("model", model).put("max_tokens", 500).put("system", SYSTEM)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", text)))
            }
        }
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val resp = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) throw RuntimeException("HTTP $code: ${resp.take(200)}")
        return when (provider) {
            0 -> JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            1 -> JSONObject(resp).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            else -> JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
        }
    }

    fun parse(raw: String): JSONObject {
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        return if (s >= 0 && e > s) JSONObject(raw.substring(s, e + 1))
        else JSONObject().put("speech", raw).put("action", "none")
    }
}

package com.example.handsfree

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject

class AssistantService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var running = false
    private var busy = false
    private var awake = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) { ttsReady = it == TextToSpeech.SUCCESS }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("assistant", "Assistant", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "assistant")
            .setContentTitle("Assistant is listening")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        running = true
        if (intent?.action == "TALK") {
            awake = true
            recognizer?.cancel()
        }
        if (!busy) listen()
        return START_STICKY
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onError(e: Int) {
            if (running && !busy) main.postDelayed({ listen() }, 700)
        }
        override fun onResults(r: Bundle?) {
            val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t.isNullOrBlank()) listen() else handle(t)
        }
    }

    private fun listen() {
        if (!running || busy) return
        main.post {
            try {
                recognizer?.destroy()
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                recognizer?.startListening(i)
            } catch (e: Exception) {
                main.postDelayed({ listen() }, 1500)
            }
        }
    }

    private fun handle(text: String) {
        if (awake) {
            awake = false
            process(text)
            return
        }
        val wake = getSharedPreferences("cfg", MODE_PRIVATE).getString("wake", "hey assistant")!!.lowercase().trim()
        val idx = text.lowercase().indexOf(wake)
        if (idx < 0) { listen(); return }
        val cmd = text.substring(idx + wake.length).trim()
        if (cmd.isEmpty()) {
            awake = true
            busy = true
            say("Yes?")
        } else process(cmd)
    }

    private fun process(cmd: String) {
        busy = true
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val p = prefs.getInt("provider", 0)
        val key = prefs.getString("key_$p", "") ?: ""
        val model = (prefs.getString("model_$p", "") ?: "").ifBlank { Llm.defaultModel(p) }
        if (key.isBlank()) { say("Please add your API key in the app."); return }
        Thread {
            var speech = ""
            var action = "none"
            var args = JSONObject()
            try {
                val j = Llm.parse(Llm.ask(p, key, model, cmd))
                speech = j.optString("speech", "")
                action = j.optString("action", "none")
                args = j.optJSONObject("args") ?: JSONObject()
            } catch (e: Exception) {
                speech = "Sorry, I could not reach the AI. Check your key and internet."
            }
            main.post {
                if (action != "none" && !Actions.run(this, action, args)) speech = "Sorry, I could not do that."
                say(speech)
            }
        }.start()
    }

    private fun say(text: String) {
        val done = { busy = false; listen() }
        if (!ttsReady || text.isBlank()) { done(); return }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { done() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { done() } }
        })
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    override fun onDestroy() {
        running = false
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}

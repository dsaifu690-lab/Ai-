package com.example.handsfree

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONObject

object Actions {
    fun run(ctx: Context, action: String, a: JSONObject): Boolean {
        return try {
            when (action) {
                "play_pause" -> key(ctx, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                "pause" -> key(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE)
                "play" -> key(ctx, KeyEvent.KEYCODE_MEDIA_PLAY)
                "next" -> key(ctx, KeyEvent.KEYCODE_MEDIA_NEXT)
                "previous" -> key(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                "volume_up" -> vol(ctx, AudioManager.ADJUST_RAISE)
                "volume_down" -> vol(ctx, AudioManager.ADJUST_LOWER)
                "play_music" -> {
                    val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                        .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                        .putExtra(SearchManager.QUERY, a.optString("query"))
                    start(ctx, i)
                }
                "open_app" -> {
                    val name = a.optString("name").lowercase()
                    val pm = ctx.packageManager
                    val app = pm.getInstalledApplications(0).firstOrNull {
                        pm.getLaunchIntentForPackage(it.packageName) != null &&
                            pm.getApplicationLabel(it).toString().lowercase().contains(name)
                    } ?: return false
                    start(ctx, pm.getLaunchIntentForPackage(app.packageName)!!)
                }
                "set_alarm" -> start(ctx, Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "set_timer" -> start(ctx, Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "call" -> {
                    val n = number(ctx, a.optString("name")) ?: return false
                    val ok = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                    start(ctx, Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$n")))
                }
                "send_sms" -> {
                    val n = number(ctx, a.optString("name")) ?: return false
                    val msg = a.optString("message")
                    if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        @Suppress("DEPRECATION")
                        val sm = SmsManager.getDefault()
                        sm.sendMultipartTextMessage(n, null, sm.divideMessage(msg), null, null)
                    } else {
                        start(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", msg))
                    }
                }
                "web_search" -> start(ctx, Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))))
                "open_url" -> start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url"))))
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun start(ctx: Context, i: Intent) {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun key(ctx: Context, code: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun vol(ctx: Context, dir: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun number(ctx: Context, name: String): String? {
        if (name.count { it.isDigit() } >= 5) return name
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }
}
